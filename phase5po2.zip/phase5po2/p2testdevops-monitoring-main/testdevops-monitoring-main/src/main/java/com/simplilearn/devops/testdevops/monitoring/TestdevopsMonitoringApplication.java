package com.simplilearn.devops.testdevops.monitoring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestdevopsMonitoringApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestdevopsMonitoringApplication.class, args);
	}

}
