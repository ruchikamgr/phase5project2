package com.simplilearn.devops.testdevops.monitoring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestdevopsMonitoringApplicationTests {

//	@Test
//	void contextLoads() {
//	}

}
